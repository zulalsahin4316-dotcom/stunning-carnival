
# Arı Organik Krem Site

Bu proje, Arı Organik Krem için tek sayfa, Shopier + EmailJS entegre web sitesidir.

## Kullanım

1. `index.html` dosyasını aç.
2. EmailJS Public Key, Service ID ve Template ID'yi doldur.
3. assets/ klasörüne ürün görsellerini ekle.
4. Tarayıcıda test et ve Vercel veya Netlify ile deploy et.

## Özellikler

- Ürünleri sepete ekleme
- Müşteri bilgilerini toplama
- Shopier ödeme yönlendirmesi
- EmailJS ile sipariş bildirimi
